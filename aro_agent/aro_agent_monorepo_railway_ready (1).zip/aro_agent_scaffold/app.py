
# Minimal FastAPI wrapper for Railway
from fastapi import FastAPI, Query
import subprocess, shlex, os

app = FastAPI()

@app.get("/")
def health():
    return {"ok": True}

@app.post("/run")
def run(query: str = Query(..., min_length=1), limit: int = 50):
    # Call the CLI module in this repo
    cmd = f"python -m aro_agent.cli --query {shlex.quote(query)} --limit {limit}"
    proc = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    return {
        "returncode": proc.returncode,
        "stdout_tail": proc.stdout[-8000:],
        "stderr_tail": proc.stderr[-8000:]
    }
