from __future__ import annotations

# API endpoints and User-Agent
ARXIV_API = "http://export.arxiv.org/api/query"           # Atom XML
CROSSREF_API = "https://api.crossref.org/works"           # JSON
DOAJ_API = "https://doaj.org/api/v2/search/articles/"     # JSON (v2)

DEFAULT_USER_AGENT = "aro-agent/0.1 (+https://example.org/contact; mailto:{email})"
REQUESTS_PER_SOURCE = 1  # Basic rate pacing per execution step (tunable)
MAX_PER_SOURCE_DEFAULT = 50
