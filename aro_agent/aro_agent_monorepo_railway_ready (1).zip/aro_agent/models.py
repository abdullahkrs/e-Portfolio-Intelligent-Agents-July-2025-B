# aro_agent/models.py
from __future__ import annotations
from dataclasses import dataclass

@dataclass
class Record:
    source: str
    doi: str | None
    arxiv_id: str | None
    title: str | None
    authors: list[str]
    abstract: str | None
    published: str | None  # ISO date
    url: str | None
    venue: str | None      # journal or container/title
    pdf_url: str | None
    license: str | None
