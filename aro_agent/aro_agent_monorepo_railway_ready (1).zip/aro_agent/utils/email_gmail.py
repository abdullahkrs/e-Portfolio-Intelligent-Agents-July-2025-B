# aro_agent/utils/email_gmail.py
from __future__ import annotations
import base64, os, mimetypes, pathlib
from email.message import EmailMessage
from typing import Iterable

from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

# Gmail scopes: send only
SCOPES = ["https://www.googleapis.com/auth/gmail.send"]

def _get_gmail_service(credentials_path: str, token_path: str):
    """
    credentials_path: path to OAuth client json (downloaded from Google Cloud)
    token_path: where we store/refresh user token (created on first run)
    """
    creds = None
    if os.path.exists(token_path):
        creds = Credentials.from_authorized_user_file(token_path, SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            from google.auth.transport.requests import Request
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(credentials_path, SCOPES)
            # Opens a browser to complete the OAuth flow (desktop app)
            creds = flow.run_local_server(port=0)
        with open(token_path, "w") as f:
            f.write(creds.to_json())
    return build("gmail", "v1", credentials=creds)

def _add_attachment(msg: EmailMessage, path: str):
    path = str(path)
    ctype, encoding = mimetypes.guess_type(path)
    if ctype is None or encoding is not None:
        ctype = "application/octet-stream"
    maintype, subtype = ctype.split("/", 1)
    with open(path, "rb") as f:
        data = f.read()
    msg.add_attachment(data, maintype=maintype, subtype=subtype, filename=os.path.basename(path))

def send_email(
    sender: str,
    to: Iterable[str] | str,
    subject: str,
    html_body: str,
    attachments: list[str] | None,
    credentials_path: str = "google_client_credentials.json",
    token_path: str = "google_token.json",
):
    """
    Sends an email via Gmail API as the authenticated user.
    - sender: must be the Gmail account you authenticate with.
    - to: one email or an iterable of emails.
    """
    if isinstance(to, str):
        to_list = [to]
    else:
        to_list = list(to)

    service = _get_gmail_service(credentials_path, token_path)

    msg = EmailMessage()
    msg["From"] = sender
    msg["To"] = ", ".join(to_list)
    msg["Subject"] = subject
    msg.set_content("This email requires an HTML-capable client.")
    msg.add_alternative(html_body, subtype="html")

    for p in attachments or []:
        if p and os.path.exists(p):
            _add_attachment(msg, p)

    raw = base64.urlsafe_b64encode(msg.as_bytes()).decode()
    resp = service.users().messages().send(userId="me", body={"raw": raw}).execute()
    return resp  # contains 'id', 'labelIds', etc.
