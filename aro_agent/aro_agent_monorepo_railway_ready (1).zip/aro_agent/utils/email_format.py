import os, json
from collections import Counter
from pathlib import Path
from .compress import make_zip
from .email_gmail import send_email

def build_and_send_email(query: str, artefacts: dict, sender: str, recipients: list[str],
                         credentials_path: str, token_path: str, attach_zip: bool = True):
    """Builds a nice HTML email (filenames only, with stats) and sends via Gmail."""

    # Load results.json
    rows = []
    try:
        with open(artefacts.get("json"), "r", encoding="utf-8") as f:
            rows = json.load(f) or []
    except Exception:
        pass

    total = len(rows)
    by_source = Counter((r.get("source") or "unknown") for r in rows)
    venues = Counter((r.get("venue") or "").strip() for r in rows if r.get("venue"))
    top_venues = venues.most_common(5)

    years = []
    for r in rows:
        p = r.get("published")
        if isinstance(p, str) and len(p) >= 4 and p[:4].isdigit():
            try:
                y = int(p[:4])
                if 1800 <= y <= 2100:
                    years.append(y)
            except:
                pass
    year_span = f"{min(years)}–{max(years)}" if years else "n/a"

    def _fname(p): return os.path.basename(p) if p else ""

    # filenames
    csv_name    = _fname(artefacts.get("csv"))
    json_name   = _fname(artefacts.get("json"))
    sqlite_name = _fname(artefacts.get("sqlite"))
    bib_name    = _fname(artefacts.get("bibtex"))

    # HTML email
    src_rows = "".join(f"<tr><td>{src}</td><td>{count}</td></tr>" for src, count in by_source.items())
    venue_rows = "".join(f"<tr><td>{name}</td><td>{count}</td></tr>" for name, count in top_venues)

    html = f"""
    <h2>ARO-Agent results</h2>
    <p><b>Query:</b> {query}</p>
    <p><b>Total records:</b> {total} | <b>Year range:</b> {year_span}</p>

    <h3>By source</h3>
    <table border="1" cellpadding="4">{src_rows or "<tr><td colspan=2>No data</td></tr>"}</table>

    <h3>Top venues</h3>
    <table border="1" cellpadding="4">{venue_rows or "<tr><td colspan=2>No data</td></tr>"}</table>

    <h3>Files</h3>
    <ul>
      {f"<li>{csv_name}</li>" if csv_name else ""}
      {f"<li>{json_name}</li>" if json_name else ""}
      {f"<li>{sqlite_name}</li>" if sqlite_name else ""}
      {f"<li>{bib_name}</li>" if bib_name else ""}
    </ul>
    """

    attachments = None
    if attach_zip:
        run_dir = Path(artefacts["json"]).parent
        zip_path = run_dir / "aro_results.zip"
        make_zip([artefacts.get("csv"), artefacts.get("json"),
                  artefacts.get("sqlite"), artefacts.get("bibtex")],
                 zip_path)
        attachments = [str(zip_path)]

    return send_email(
        sender=sender,
        to=recipients,
        subject=f"ARO-Agent results: {query}",
        html_body=html,
        attachments=attachments,
        credentials_path=credentials_path,
        token_path=token_path,
    )
