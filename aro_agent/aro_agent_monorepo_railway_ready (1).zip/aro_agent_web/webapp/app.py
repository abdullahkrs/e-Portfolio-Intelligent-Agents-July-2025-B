# webapp/app.py
from __future__ import annotations
import os, json
from pathlib import Path
from flask import Flask, render_template, request, redirect, url_for, flash, send_file, abort,send_from_directory
import hashlib
from typing import Any

# (A) import your library pieces
from aro_agent.agents.coordinator import CoordinatorAgent
from aro_agent.utils.email_gmail import send_email         # NEW
from aro_agent.utils.compress import make_zip              # NEW
import aro_agent
from aro_agent.utils.email_format import build_and_send_email


app = Flask(__name__)
app.secret_key = os.environ.get("ARO_SECRET_KEY", "dev-secret")
print("TEMPLATE SEARCH PATHS:", app.jinja_loader.searchpath)
app.config['TEMPLATES_AUTO_RELOAD'] = True
app.jinja_env.auto_reload = True



APP_ROOT = Path(__file__).resolve().parents[1]     # .../aro_agent_web
PKG_ROOT = Path(aro_agent.__file__).resolve().parent   # .../aro_agent_scaffold/aro_agent
SCAFFOLD_ROOT = PKG_ROOT.parent                        # .../aro_agent_scaffold
OUT_ROOT = (SCAFFOLD_ROOT / "out").resolve()           # shared OUT for scaffold
os.environ["ARO_OUT_ROOT"] = str(OUT_ROOT)         # <-- key line
PKG_ROOT = Path(aro_agent.__file__).resolve().parent.parent
MAIL_FROM   = os.environ.get("ARO_MAIL_FROM", "ggmmgg9@gmail.com")
GMAIL_CREDS = os.environ.get("ARO_GMAIL_CREDS", str(PKG_ROOT / "google_client_credentials.json"))
GMAIL_TOKEN = os.environ.get("ARO_GMAIL_TOKEN", str(PKG_ROOT / "google_token.json"))
DEFAULT_MAIL_TO = os.environ.get("ARO_MAIL_TO", "ggmmgg9@gmail.com")
CROSSREF_CONTACT = os.environ.get("ARO_CONTACT_EMAIL", "ggmmgg9@gmail.com")

def _job_key_from_meta(meta: dict[str, Any]) -> dict[str, Any]:
    """Stable key for grouping runs into a Job (standing query)."""
    query = (meta.get("query") or "").strip()
    from_year = meta.get("from_year")
    to_year = meta.get("to_year")
    enabled = meta.get("sources_enabled") or {}
    sources = sorted([k for k, v in enabled.items() if v])
    return {"query": query, "from_year": from_year, "to_year": to_year, "sources": sources}

def _job_id_from_key(key: dict[str, Any]) -> str:
    j = json.dumps(key, sort_keys=True).encode("utf-8")
    return hashlib.sha1(j).hexdigest()[:12]

def _job_dir(job_id: str) -> Path:
    return OUT_ROOT / "jobs" / job_id

def _job_schedule_path(job_id: str) -> Path:
    return _job_dir(job_id) / "SCHEDULE.json"

def _get_job_schedule(job_id: str) -> dict[str, Any]:
    p = _job_schedule_path(job_id)
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {"enabled": False, "frequency": "weekly"}


def list_runs():
    runs = []
    if OUT_ROOT.exists():
        for d in sorted(OUT_ROOT.glob("run_*"), key=lambda p: p.name, reverse=True):
            query = None
            counts = {}
            timestamp = None
            new_items = 0
            meta: dict[str, Any] = {}

            rj = d / "run.json"
            if rj.exists():
                try:
                    meta = json.loads(rj.read_text(encoding="utf-8")) or {}
                    query = meta.get("query")
                    counts = meta.get("counts") or {}
                    timestamp = meta.get("timestamp")
                except Exception:
                    meta = {}

            # compute diff count
            diff = d / "diff.csv"
            if diff.exists():
                try:
                    with diff.open("r", encoding="utf-8") as f:
                        new_items = max(0, sum(1 for _ in f) - 1)
                except Exception:
                    new_items = 0

            # compute job id from meta
            key = _job_key_from_meta(meta) if meta else {"query": query, "from_year": None, "to_year": None, "sources": []}
            job_id = _job_id_from_key(key)

            runs.append({
                "id": d.name,
                "job_id": job_id,
                "key": key,
                "has_schedule": _job_schedule_path(job_id).exists(),
                "timestamp": timestamp,
                "query": query,
                "counts": counts,
                "new_items": new_items,
            })
    return runs

def list_jobs():
    """Group runs by job_id; include schedule state and latest run summary."""
    jobs: dict[str, dict[str, Any]] = {}
    for r in list_runs():
        jid = r["job_id"]
        j = jobs.setdefault(jid, {
            "job_id": jid,
            "key": r["key"],
            "query": r["query"],
            "schedule": _get_job_schedule(jid),
            "runs": [],
        })
        j["runs"].append(r)

    # sort runs per job (newest first)
    for j in jobs.values():
        j["runs"].sort(key=lambda x: x["id"], reverse=True)

    # sort jobs by newest run time
    ordered = sorted(jobs.values(), key=lambda j: j["runs"][0]["id"] if j["runs"] else "", reverse=True)
    return ordered


def _run_search(query: str, limit: int, email: str, from_year: int | None, to_year: int | None,
                enable_sources: dict[str, bool]) -> dict:
    coord = CoordinatorAgent(contact_email=email, timeout=15.0, enable_sources=enable_sources, run_root=OUT_ROOT)
    artefacts = coord.run(
        query=query,
        per_source_limit=limit,
        from_year=from_year,
        to_year=to_year
    )
    return artefacts

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        query = (request.form.get("query") or "").strip()
        email = CROSSREF_CONTACT
        limit = int(request.form.get("limit") or "50")
        from_year = request.form.get("from_year")
        to_year = request.form.get("to_year")
        from_year = int(from_year) if from_year else None
        to_year = int(to_year) if to_year else None

        enable_sources = {
            "arxiv": bool(request.form.get("src_arxiv")),
            "crossref": bool(request.form.get("src_crossref")),
            "doaj": bool(request.form.get("src_doaj")),
        }
        if not any(enable_sources.values()):
            flash("Please select at least one source.", "error")
            return redirect(url_for("index"))
        if not query:
            flash("Query is required.", "error")
            return redirect(url_for("index"))

        artefacts = _run_search(query, limit, email, from_year, to_year, enable_sources)
        def _abs(p: str | None) -> Path | None:
            if not p:
                return None
            pth = Path(p)
            return pth if pth.is_absolute() else (APP_ROOT / pth).resolve()

        # Normalize file paths to absolute
        abs_csv    = _abs(artefacts.get("csv"))
        abs_json   = _abs(artefacts.get("json"))
        abs_sqlite = _abs(artefacts.get("sqlite"))
        abs_bib    = _abs(artefacts.get("bibtex"))

        # Compute rel paths under OUT_ROOT for serving via route
        def _rel_to_out(p: Path | None) -> str | None:
            if not p:
                return None
            # Ensure file is under OUT_ROOT; if coordinator wrote elsewhere, fallback to relative from OUT_ROOT
            try:
                return str(p.resolve().relative_to(OUT_ROOT))
            except ValueError:
                # Not under OUT_ROOT; place a copy in OUT_ROOT if you prefer. For now, block serving.
                return None

        links = {
            "csv":   _rel_to_out(abs_csv),
            "json":  _rel_to_out(abs_json),
            "sqlite":_rel_to_out(abs_sqlite),
            "bibtex":_rel_to_out(abs_bib),
        }

        # Load results.json for rendering
        rows = []
        try:
            with open(artefacts["json"], "r", encoding="utf-8") as f:
                rows = json.load(f)
        except Exception:
            pass

        return render_template("results.html",
            query=query,
            rows=rows,
            artefacts=artefacts,
            links=links,
            default_mail_to=DEFAULT_MAIL_TO
        )

    return render_template("index.html", jobs=list_jobs())


@app.get("/schedule")
def schedule_latest():
    runs = list_runs()
    if not runs:
        return render_template("schedule_missing.html", runs=[], run=None, has_schedule=False)

    # pick run by ?run=<id> or latest
    run_id = request.args.get("run") or runs[0]["id"]
    run = next((r for r in runs if r["id"] == run_id), None)
    if not run:
        abort(404)

    sched_path = OUT_ROOT / run_id / "SCHEDULE.txt"
    if not sched_path.exists():
        return render_template("schedule_missing.html", runs=runs, run=run, has_schedule=False)

    text = sched_path.read_text(encoding="utf-8")

    # parse for convenience (not required, but nice to show separate blocks)
    lines = [ln.rstrip() for ln in text.splitlines()]
    win_lines = [ln for ln in lines if ln.strip().lower().startswith("schtasks ")]
    cron_lines = []
    in_cron = False
    for ln in lines:
        if "cron (linux" in ln.lower(): in_cron = True; continue
        if in_cron: cron_lines.append(ln)

    return render_template(
        "schedule.html",
        runs=runs,
        run=run,
        has_schedule=True,
        schedule_text=text,
        windows_cmd="\n".join(win_lines) if win_lines else "",
        cron_block="\n".join(cron_lines).strip()
    )

@app.get("/runs/<run_id>")
def view_run(run_id):
    run_dir = OUT_ROOT / run_id
    if not run_dir.exists():
        abort(404)

    rj = run_dir / "run.json"
    if not rj.exists():
        abort(404)

    try:
        meta = json.loads(rj.read_text(encoding="utf-8"))
    except Exception:
        meta = {}

    # artefact paths
    csv_p = run_dir / "results.csv"
    json_p = run_dir / "results.json"
    sql_p = run_dir / "results.sqlite"
    bib_p = run_dir / "results.bib"

    def _rel(p: Path) -> str | None:
        return str(p.resolve().relative_to(OUT_ROOT)) if p.exists() else None

    links = {"csv": _rel(csv_p), "json": _rel(json_p), "sqlite": _rel(sql_p), "bibtex": _rel(bib_p)}

    rows = []
    if json_p.exists():
        try:
            rows = json.loads(json_p.read_text(encoding="utf-8")) or []
        except Exception:
            rows = []

    return render_template("results.html",
        query=meta.get("query") or "(unknown)",
        rows=rows,
        artefacts={"csv": str(csv_p), "json": str(json_p), "sqlite": str(sql_p), "bibtex": str(bib_p)},
        links=links,
        default_mail_to=""
    )

@app.post("/jobs/<job_id>/schedule/enable")
def job_schedule_enable(job_id):
    jd = _job_dir(job_id)
    jd.mkdir(parents=True, exist_ok=True)
    sched = _job_schedule_path(job_id)
    # Keep whatever you want here (public-friendly, no shell)
    payload = {"enabled": True, "frequency": "weekly"}
    sched.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    flash("Scheduling enabled for this job.", "info")
    return redirect(url_for("index"))

@app.post("/jobs/<job_id>/schedule/disable")
def job_schedule_disable(job_id):
    sched = _job_schedule_path(job_id)
    if sched.exists():
        sched.unlink()
        flash("Scheduling disabled for this job.", "info")
    else:
        flash("Schedule was not enabled.", "warning")
    return redirect(url_for("index"))

@app.get("/runs/<run_id>/SCHEDULE.txt")
def download_schedule(run_id):
    run_dir = OUT_ROOT / run_id
    if not run_dir.exists(): abort(404)
    path = run_dir / "SCHEDULE.txt"
    if not path.exists(): abort(404)
    return send_from_directory(run_dir, "SCHEDULE.txt", as_attachment=True, download_name="SCHEDULE.txt")

@app.post("/runs/<run_id>/schedule/enable")
def enable_schedule(run_id):
    run_dir = OUT_ROOT / run_id
    if not run_dir.exists():
        abort(404)

    rj = run_dir / "run.json"
    if not rj.exists():
        flash("run.json missing; cannot create schedule.", "error")
        return redirect(url_for("index"))

    meta = json.loads(rj.read_text(encoding="utf-8"))
    # reconstruct the base CLI command from run.json
    q = (meta.get("query") or "").replace('"', r'\"')
    limit = int(meta.get("per_source_limit") or 200)
    enabled = meta.get("sources_enabled") or {}
    sources = ",".join([k for k, v in enabled.items() if v])

    parts = [f'python -m aro_agent.cli --query "{q}" --limit {limit}']
    if sources:
        parts.append(f"--sources {sources}")
    fy = meta.get("from_year")
    ty = meta.get("to_year")
    if fy is not None:
        parts.append(f"--from-year {fy}")
    if ty is not None:
        parts.append(f"--to-year {ty}")
    parts.append(f'--out "{OUT_ROOT.resolve()}"')
    base_cmd = " ".join(parts)

    schedule_text = (
        'REM ---- Windows Task Scheduler ----\n'
        f'schtasks /Create /SC WEEKLY /TN "ARO-Agent - {q}" /TR "{base_cmd}" /ST 09:00 /RL LIMITED\n\n'
        '### ---- cron (Linux/macOS) ----\n'
        '# Add this line to your crontab (crontab -e):\n'
        f'0 9 * * 1 cd "{OUT_ROOT.resolve()}" && {base_cmd} >> aro_agent.log 2>&1\n'
    )
    (run_dir / "SCHEDULE.txt").write_text(schedule_text, encoding="utf-8")
    flash("Schedule enabled (SCHEDULE.txt written).", "info")
    return redirect(url_for("index"))

@app.post("/runs/<run_id>/schedule/disable")
def disable_schedule(run_id):
    run_dir = OUT_ROOT / run_id
    if not run_dir.exists():
        abort(404)
    sched = run_dir / "SCHEDULE.txt"
    if sched.exists():
        sched.unlink()
        flash("Schedule disabled (SCHEDULE.txt removed).", "info")
    else:
        flash("No SCHEDULE.txt to remove.", "warning")
    return redirect(url_for("index"))

@app.post("/jobs/<job_id>/run")
def job_run_now(job_id):
    # choose the latest run to reconstruct parameters (query, years, sources)
    jobs = {j["job_id"]: j for j in list_jobs()}
    job = jobs.get(job_id)
    if not job or not job["runs"]:
        flash("No past run found to reconstruct parameters.", "error")
        return redirect(url_for("index"))

    # reconstruct params from latest run meta
    latest_run = job["runs"][0]
    run_dir = OUT_ROOT / latest_run["id"]
    meta = json.loads((run_dir / "run.json").read_text(encoding="utf-8"))
    query = meta.get("query") or ""
    limit = int(meta.get("per_source_limit") or 200)
    from_year = meta.get("from_year")
    to_year = meta.get("to_year")
    enable_sources = meta.get("sources_enabled") or {}

    # Run the search
    artefacts = _run_search(query, limit, DEFAULT_MAIL_TO, from_year, to_year, enable_sources)

    # Redirect to newly created run page
    # pick artefacts json to get the run folder
    from pathlib import Path as _P
    run_dir = _P(artefacts.get("json")).parent if artefacts.get("json") else OUT_ROOT
    return redirect(url_for("view_run", run_id=run_dir.name))


@app.get("/artifact/<path:subpath>")
def artifact(subpath: str):
    full = (OUT_ROOT / subpath).resolve()
    # Prevent path traversal
    if not str(full).startswith(str(OUT_ROOT)) or not full.exists() or not full.is_file():
        abort(404)
    return send_file(str(full), as_attachment=False)

@app.post("/zip")
def create_zip_and_download():
    artefacts_json = request.form.get("artefacts_json")
    if not artefacts_json:
        flash("No artefacts provided.", "error")
        return redirect(url_for("index"))
    artefacts = json.loads(artefacts_json)

    # Use absolute run dir derived from results.json
    json_path = artefacts.get("json")
    if not json_path:
        flash("Missing JSON artefact.", "error")
        return redirect(url_for("index"))

    json_abs = Path(json_path)
    if not json_abs.is_absolute():
        json_abs = (APP_ROOT / json_abs).resolve()

    run_dir = json_abs.parent
    zip_path = run_dir / "aro_results.zip"

    make_zip(
        [artefacts.get("csv"), artefacts.get("json"),
         artefacts.get("sqlite"), artefacts.get("bibtex")],
        zip_path
    )
    return send_file(str(zip_path), as_attachment=True, download_name="aro_results.zip")

@app.post("/send")
def send_email_results():
    if not MAIL_FROM:
        flash("Server is missing ARO_MAIL_FROM.", "error")
        return redirect(url_for("index"))

    artefacts_json = request.form.get("artefacts_json")
    if not artefacts_json:
        flash("No artefacts provided.", "error")
        return redirect(url_for("index"))
    artefacts = json.loads(artefacts_json)

    mail_to = (request.form.get("mail_to") or "").strip()
    if not mail_to:
        flash("Please provide a recipient email.", "error")
        return redirect(url_for("index"))

    resp = build_and_send_email(
        query=request.form.get("query") or "",
        artefacts=artefacts,
        sender=MAIL_FROM,
        recipients=[t.strip() for t in mail_to.replace(";", ",").split(",") if t.strip()],
        credentials_path=GMAIL_CREDS,
        token_path=GMAIL_TOKEN,
        attach_zip=bool(request.form.get("attach_zip")),
    )
    flash(f"Email sent. Gmail message id: {resp.get('id')}", "info")
    return redirect(url_for("index"))

@app.template_filter("join_authors")
def join_authors(auth):
    if isinstance(auth, list):
        return "; ".join(a for a in auth if a)
    return auth or ""

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 8000)), debug=True)
