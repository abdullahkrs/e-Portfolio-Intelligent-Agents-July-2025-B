
import os, subprocess, shlex, sys
QUERY = os.getenv("CRON_QUERY", "machine learning")
LIMIT = os.getenv("CRON_LIMIT", "50")
cmd = f"python -m aro_agent.cli --query {shlex.quote(QUERY)} --limit {shlex.quote(LIMIT)}"
print("Running:", cmd)
proc = subprocess.run(cmd, shell=True)
sys.exit(proc.returncode)
